@extends('layouts.app')
@section('content')

@if (!is_null($viewdata->get('list')))
<table class="table table-primary table-small" id="applies">
    <thead>
        <tr>
            <th>No</th>
            <th>JANコード</th>
            <th>商品名</th>
            <th>規格単位</th>
            <th>メーカー</th>
            <th>薬価（円）</th>
            <th>状態</th>
            <th>施設</th>
            <th>担当</th>
            <th>申請者</th>
            <th>申請日</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        @foreach($viewdata->get('list') as $apply)
        <tr>
            <td class="target-apply">{{ $apply->kon_medicine_id }}</td>
            <td class="target-apply medicine">{{ $apply->jan_code }}</td>
            <td class="target-apply medicine">{{ $apply->medicine_name }}</td>
            <td class="target-apply medicine">{{ $apply->standard_unit }}</td>
            <td class="target-apply medicine">{{ $apply->maker_name }}</td>
            <td class="target-apply">{{ $apply->price }}</td>
            <td class="target-apply"><span class="badge badge-{{ App\Helpers\Apply\getStatusBadgeClass($apply->status)}}">{{ App\Model\Task::getStatus($apply->status) }}</span></td>
            <td class="target-apply">{{ $apply->facility_name }}</td>
            <td class="target-apply"></td>
            <td class="target-apply">{{ $apply->user_name }}</td>
            <td class="target-apply">{{ $apply->application_date }}</td>
            <td class="target-apply">
                @if (!is_null($apply->button['url']))
                <form action="{{ $apply->button['url'] }}">
                <button class="btn btn-primary btn-sm" type="submit" data-toggle="modal" data-target="#modal-action">{{ $apply->button['label'] }}</button>
                </form>
                @endif
            </td>
        </tr>
        @endforeach
    </tbody>
@endif
@endsection
