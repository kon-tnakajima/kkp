@extends('layouts.app')
@section('content')
detail
@endsection
