@extends('layouts.app')
@section('content')

{{ var_dump($viewdata->get('medicine')) }}

@endsection
