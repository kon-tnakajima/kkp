<?php

namespace App\Services;

use App\Model\Medicine;
use App\Model\PriceAdoption;
use App\Model\Task;
use App\Model\Valiation;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
class ApplyService 
{
    /*
     * コンストラクタ
     */
    public function __construct()
    {
        $this->medicine = new Medicine();
        $this->priceAdoption = new PriceAdoption();
        $this->valiation = new Valiation();
    }
    /*
     * 採用申請一覧取得
     */
    public function getApplyList(Request $request)
    {
        $user = Auth::user();
        $list =  $this->medicine->listWithApply($user->facility);

        // リストにボタン情報付加
        if (!is_null($list)) {
            foreach($list as $key => $apply) {
                $list[$key]->button = $this->button($apply);
            }
        }
        return $list;
    }

    /*
     * 標準薬品情報取得
     */
    public function getMedicine($id)
    {
        return $this->medicine->find($id);
    }

    /*
     * 採用申請実行
     */
    public function regist(Request $request)
    {
        \DB::beginTransaction();
        try {
            $medicine = $this->medicine->find($request->id);
            // price_adoptionsに登録
            $user = Auth::user();
            $data = array();
            $data['facility_id'] = $user->facility->id;
            $data['medicine_id'] = $request->id;
            $data['user_id'] = $user->id;
            $data['application_date'] = date('Y-m-d H:i:s');
            $data['status'] = Task::STATUS_APPLYING; // 申請中からスタート
            $data['purchase_price'] = $medicine->medicinePrice->price;
            $data['sales_price'] = $medicine->medicinePrice->price;
            $priceAdoption = $this->priceAdoption->create($data);

            // valiationデータ作成
            $data = array();
            $data['price_adoption_id'] = $priceAdoption->id;
            $data['current_task_id'] = Task::current($priceAdoption->status)->id;
            $data['next_task_id'] = Task::next($priceAdoption->status)->id;

            $valation = $this->valiation->create($data);
            \DB::commit();

            return true;
            
        } catch (\PDOException $e){
            echo $e->getMessage();
            \DB::rollBack();
            return false;
        }
    }

    /*
     * 採用許可
     */
    public function allow(Request $request)
    {

        // TODOバリデーション
        return $this->next($request);
    }

    /*
     * 価格確定
     */
    public function confirm(Request $request)
    {
        // TODOバリデーション
        return $this->next($request);
    }

    /*
     * next
     */
    public function next(Request $request)
    {
        \DB::beginTransaction();
        try {
            // valation取得
            $valiation = $this->valiation->where('price_adoption_id', $request->id)->first();

            // price_adoptions取得
            $pa = $this->priceAdoption->find($request->id);
            $next = Task::next($pa->status);

            $user = Auth::user();
            $pa->approval_user_id = $user->id;
            $pa->status = $next->status; // 現在のステータスをセット
            $pa->save();

            // valiationデータ更新
            $valiation->current_task_id = $valiation->next_task_id;
            $valiation->next_task_id = $next->id;
            $valiation->save();

            \DB::commit();

            return true;
            
        } catch (\PDOException $e){
            echo $e->getMessage();
            exit;
            \DB::rollBack();
            return false;
        }
    }
    /*
     * 採用一覧のボタンの情報を返す
     */
    function button($apply) 
    {
        $property = [
            'url' => null,
            'label' => ''
        ];

        // ステータスとログインしているユーザの施設により処理が変わる
        // 病院の場合
        if (isHospital()) {
            // デフォルトは採用申請
            $property = [
                'url' => route('apply.regist',['id' => $apply->medicine_id ]),
                'label' => '採用申請'
            ];
            // 申請中は「取り下げ」ボタン
            if ($apply->status === TASK::STATUS_APPLYING) {
                $property = [
                    'url' => route('apply.regist',['id' => $apply->medicine_id ]),
                    'label' => '取り下げ'
                ];
            }

            // 採用可は「採用」ボタン
            if ($apply->status === TASK::STATUS_ADOPTABLE) {
                $property = [
                    'url' => route('apply.regist',['id' => $apply->price_adoption_id ]),
                    'label' => '採用'
                ];
            }
            // 交渉中は催促
            if ($apply->status === TASK::STATUS_NEGOTIATING) {
                $property = [
                    'url' => route('apply.regist',['id' => $apply->price_adoption_id ]),
                    'label' => '催促'
                ];
            }
        }
        // 本部の場合
        if (isHeadQuqrters()) {
            // 申請中は「許可」ボタン
            if ($apply->status === TASK::STATUS_APPLYING) {
                $property = [
                    'url' => route('apply.allow',['id' => $apply->price_adoption_id ]),
                    'label' => '許可'
                ];
            }
            // 承認待は「採用承認」
            if ($apply->status === TASK::STATUS_APPROVAL_WAITING) {
                $property = [
                    'url' => route('apply.regist',['id' => $apply->price_adoption_id ]),
                    'label' => '採用承認'
                ];
            }
            // 交渉中は「取り下げ」ボタン
            if ($apply->status === TASK::STATUS_NEGOTIATING) {
                $property = [
                    'url' => route('apply.allow',['id' => $apply->price_adoption_id ]),
                    'label' => '取り下げ'
                ];
            }
        }

        // 文化連の場合
        if (isBunkaren()) {
            // 交渉中は「価格確定」
            if ($apply->status === TASK::STATUS_NEGOTIATING) {
                $property = [
                    'url' => route('apply.confirm',['id' => $apply->price_adoption_id ]),
                    'label' => '価格確定'
                ];
            }
        }
        return $property;
    }

}
