<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller as BaseController;
use App\Services\ApplyService;
use App\Helpers\Apply;
use Illuminate\Http\Request;

class ApplyController extends BaseController
{
    /* ビジネスロジックのオブジェクト */
    private $applyService;

    protected $function_id = 1;

    /*
     * コンストラクタ
     */
    public function __construct()
    {
        $this->service = new ApplyService();
    }
    /*
     * 採用申請一覧
     */
    public function index(Request $request)
    {
        // 一覧取得
        $this->setViewData([
            'list' => $this->service->getApplyList($request),
        ]);
        return view(\Route::currentRouteName(),  $this->getViewArray());
    }

    /*
     * 採用申請実行
     */
    public function regist(Request $request)
    {
        if (!$this->service->regist($request)) {
            // エラーメッセージ
        }
        return redirect()->route('apply.index');
    }

    /*
     * 申請許可(本部)
     */
    public function allow(Request $request)
    {
        if (!$this->service->allow($request)) {
            // エラーメッセージ
        }
        return redirect()->route('apply.index');
    }
    
    /*
     * 価格確定(文化連)
     */
    public function confirm(Request $request)
    {
        if (!$this->service->allow($request)) {
            // エラーメッセージ
        }
        return redirect()->route('apply.index');
    }

    /*
     * 採用申請詳細
     */
    public function detail(Request $request)
    {
        return view(\Route::currentRouteName(),  $this->getViewArray());
    }
}
