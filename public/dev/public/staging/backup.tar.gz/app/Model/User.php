<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailContract;
use Illuminate\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Model\Role;
use App\Model\UserGroup;

class User extends Authenticatable implements MustVerifyEmailContract
{
    use MustVerifyEmail, Notifiable;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'facilities_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /*
     * アクセス権限があるかどうか
     * @param int $function_id 機能ID
     * @return boolean
     */
    public function isAccessAllowed($function_id)  
    {
        $user = $this->joinRole();
        $user = $user->where('roles.function_id', '=', $function_id);
        $user->orderBy('roles.level', 'desc'); // 一番大きいlevelを取得

        $data = $user->first();
        if (!is_null($data) ) {
            if ($data->level === Role::LEVEL_ENABLE) {
                return true;
            }
        }
        return false;
    }

    public function joinRole()
    {
        $user = $this->join('user_group_relations', 'users.id', '=', 'user_group_relations.user_id');
        $user = $user->join('user_groups', 'user_group_relations.user_group_id', '=', 'user_groups.id');
        $user = $user->join('roles', 'roles.user_group_id', '=', 'user_groups.id');
        return $user;
    }

    /*
     * 所属するグループを取得
     */
    public function userGroups() 
    {
        return $this->belongsToMany('App\Model\UserGroup', 'user_group_relations');
    }

    /*
     * 施設を取得
     */
    public function facility()
    {
        return $this->belongsTo('App\Model\Facility');
    }

    /*
     * アクタIDを取得
     */
    public function getActorID()
    {
        return $this->userGroups()->first()->facility->actor_id;
    }


}
