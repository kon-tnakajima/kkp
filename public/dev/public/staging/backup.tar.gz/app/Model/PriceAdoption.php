<?php

namespace App\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class PriceAdoption extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'facility_id',
        'medicine_id', 
        'user_id', 
        'application_date', 
        'status', 
        'approval_user_id', 
        'purchase_price', 
        'sales_price', 
        'deleter', 
        'creater', 
        'updater'
        ];

    /*
     * 標準薬品を取得
     */
    public function medicine()
    {
        return $this->hasOne('App\Model\Medicine');
    }
    /* 
     * 施設レベルによりwhere句を変更
     */
    public function scopeFacility($query, Facility $facility)
    {
        // 病院
        if ($facility->isHospital() === true)  {
            $query->where('facility_id', '=', $facility->id);
        }

        // 本部
        if ($facility->isHeadQuqrters() === true) {
            $ids = array();
            foreach($facility->children as $child) {
                $ids[] = $child->id;
            }
            $query->whereIn('facility_id', $ids);
        }

        return $query;
    }


}
