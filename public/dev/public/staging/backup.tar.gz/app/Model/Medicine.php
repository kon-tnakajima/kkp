<?php

namespace App\Model;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use App\Model\Facility;
use App\Model\PriceAdoption;
use App\Model\MedicinePrice;

class Medicine extends Model
{
    use SoftDeletes;

    protected $guraded = ['id'];

    /*
     * 承認申請一覧
     */
    public function listWithApply(Facility $facility)
    {
        // サブクエリ
        $pa = new PriceAdoption();

        $list = $this->select('medicines.id as medicine_id' 
                              ,'medicines.kon_medicine_id'
                              ,'pack_units.jan_code'
                              ,'medicines.name as medicine_name'
                              ,'medicines.standard_unit as standard_unit'
                              ,'makers.name as maker_name'
                              ,'medicine_prices.price as price'
                              ,'pa.status as status'
                              ,'facilities.name as facility_name'
                              ,'users.name as user_name'
                              ,'pa.application_date as application_date'
                              ,'pa.id as price_adoption_id'
                             )
                ->join('pack_units', 'medicines.id', '=', 'pack_units.medicine_id')
                ->join('makers', 'medicines.maker_id', '=', 'makers.id')
                ->join('medicine_prices', 'medicines.id', '=', 'medicine_prices.medicine_id')
                ->leftJoinSub($pa->facility($facility), 'pa', function($join){
                    $join->on('medicines.id', '=', 'pa.medicine_id');
                })
                ->leftJoin('facilities', 'facilities.id', '=', 'pa.facility_id')
                ->leftJoin('users', 'users.id', '=', 'pa.user_id')
                ->get();
        return $list;
    }

    /*
     * 薬価の取得
     */
    public function medicinePrice()
    {
        return $this->hasOne('App\Model\MedicinePrice');;
    }

}
