<?php

namespace App\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class FacilityMedicine extends Model
{
    use SoftDeletes;

    /*
     * 標準薬品を取得
     */
    public function medicine()
    {
        return $this->hasOne('App\Model\Medicine');
    }
    /* 
     * 施設レベルによりwhere句を変更
     */
    public function scopeFacility($query, Facility $facility)
    {
        // 病院
        if ($facility->isHospital() === true)  {
            $query->where('facility_id', '=', $facility->id);
        }

        // 本部
        if ($facility->isHeadQuqrters() === true) {
            $ids = array();
            foreach($facility->children as $child) {
                $ids[] = $child->id;
            }
            $query->whereIn('facility_id', $ids);
        }

        return $query;
    }

}
