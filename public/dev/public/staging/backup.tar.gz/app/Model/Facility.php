<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\Actor;

class Facility extends Model
{
    protected $guraded = ['id'];
    /* 
     * 文化連かどうか判定
     */
    public function isBunkaren() {
        return Actor::isBunkaren($this->actor_id);
    }

    /* 
     * 本部かどうか判定
     */
    public function isHeadQuqrters() {
        return Actor::isHeadQuqrters($this->actor_id);
    }

    /* 
     * 病院かどうか判定
     */
    public function isHospital() {
        return Actor::isHospital($this->actor_id);
    }

    /*
     * 本部の配下の施設(病院)を取得
     */
    public function children() {
        return $this->belongsToMany('App\Model\Facility', 'facility_relations', 'parent_facility_id', 'facility_id');
    }
}
