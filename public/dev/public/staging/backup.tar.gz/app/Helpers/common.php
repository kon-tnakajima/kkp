<?php
/*
 * 全Viewで使用するHelper関数
 */

/*
 * 文化連かどうか
 */
function isBunkaren()
{
    return (App\Model\Actor::isBunkaren(Auth::user()->getActorID())) ;
}

/*
 * 病院かどうか
 */
function isHospital()
{
    return (App\Model\Actor::isHospital(Auth::user()->getActorID())) ;
}

/*
 * 本部かどうか
 */
function isHeadQuqrters()
{
    return (App\Model\Actor::isHeadQuqrters(Auth::user()->getActorID())) ;
}
?>
