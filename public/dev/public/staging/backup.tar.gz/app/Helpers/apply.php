<?php

namespace App\Helpers\Apply
{
    use App\Model\Task;
    /*
     * ステータスのバッチのクラス名取得
     */
    function getStatusBadgeClass($status)
    {
	 switch($status) {
            case TASK::STATUS_APPLYING:
                return "applying";
            case TASK::STATUS_NEGOTIATING:
                return "negotiation";
            case TASK::STATUS_APPROVAL_WAITING:
                return "approval";
            case TASK::STATUS_UNCONFIRMED:
                return "unconfirmed";
            case TASK::STATUS_ADOPTABLE:
                return "adopt";
            case TASK::STATUS_DONE:
                return "adopted";
            default: 
                return "not_adopted";

        }
    }

}
