<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'facility_id' => 3,
                'name' => '藤田1',
                'password' => '$2y$10$.PBYNqA35cQPvOnPYHw3xOaYsfNreF35IVb1J1OoTb.WmyY1crz5a',
                'email' => 'fujita+1@whizzy.co.jp',
                'email_verified_at' => now(),
                'last_login_at' => now(),
                'remember_token' => 's2ZCmMQWeXOch1DQLOIBpPj0G10DBxSumy70Ac2kQJ0iZ3yNXwOG7VNXIbmW',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'facility_id' => 2,
                'name' => '本部',
                'password' => '$2y$10$DHp2DPcpBHgeqtyOrwiyluR7L04utMV88llXqYtycDk142uTxUq2S',
                'email' => 'fujita+honbu@whizzy.co.jp',
                'email_verified_at' => now(),
                'last_login_at' => now(),
                'remember_token' => 'alfQm6BT6Jal72r5jZOqjLLFCsVUBXrViCeXy6Aqrl1UVToClobXiGIyp8FG',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'facility_id' => 3,
                'name' => '文化連',
                'password' => '$2y$10$oigcVie7EljHagJ132PLLe8CW6hBIj23Jt6KdsSL0fFDDFdhpHoUW',
                'email' => 'fujita+bunkaren@whizzy.co.jp',
                'email_verified_at' => now(),
                'last_login_at' => now(),
                'remember_token' => '',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ]);
    }
}
