<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes(['verify' => true]);

Route::get('/', function () { return view('welcome'); });
Route::middleware(['verified'])->group(function() {
    Route::match('get', '/home', 'HomeController@index');
    Route::match('get', '/apply', 'ApplyController@index')->name('apply.index');
    Route::match('get', '/apply/regist/{id}', 'ApplyController@regist')->name('apply.regist'); // idはmedicines.id
    Route::match('get', '/apply/allow/{id}', 'ApplyController@allow')->name('apply.allow'); // idはprice_adoption.id
    Route::match('get', '/apply/confirm/{id}', 'ApplyController@allow')->name('apply.confirm'); // idはprice_adoption.id
    Route::match('get', '/apply/detail/{id}', 'ApplyController@detail')->name('apply.detail'); // idはprice_adoption.id
});

