<?php $__env->startSection('content'); ?>

<?php if(!is_null($viewdata->get('list'))): ?>
<table class="table table-primary table-small" id="applies">
    <thead>
        <tr>
            <th>No</th>
            <th>JANコード</th>
            <th>商品名</th>
            <th>規格単位</th>
            <th>メーカー</th>
            <th>薬価（円）</th>
            <th>状態</th>
            <th>施設</th>
            <th>担当</th>
            <th>申請者</th>
            <th>申請日</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $viewdata->get('list'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="target-apply"><?php echo e($apply->kon_medicine_id); ?></td>
            <td class="target-apply medicine"><?php echo e($apply->jan_code); ?></td>
            <td class="target-apply medicine"><?php echo e($apply->medicine_name); ?></td>
            <td class="target-apply medicine"><?php echo e($apply->standard_unit); ?></td>
            <td class="target-apply medicine"><?php echo e($apply->maker_name); ?></td>
            <td class="target-apply"><?php echo e($apply->price); ?></td>
            <td class="target-apply"><span class="badge badge-<?php echo e(App\Helpers\Apply\getStatusBadgeClass($apply->status)); ?>"><?php echo e(App\Model\Task::getStatus($apply->status)); ?></span></td>
            <td class="target-apply"><?php echo e($apply->facility_name); ?></td>
            <td class="target-apply"></td>
            <td class="target-apply"><?php echo e($apply->user_name); ?></td>
            <td class="target-apply"><?php echo e($apply->application_date); ?></td>
            <td class="target-apply">
                <?php if(!is_null($apply->button['url'])): ?>
                <form action="<?php echo e($apply->button['url']); ?>">
                <button class="btn btn-primary btn-sm" type="submit" data-toggle="modal" data-target="#modal-action"><?php echo e($apply->button['label']); ?></button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>