<?php $__env->startSection('content'); ?>

<?php echo e(var_dump($viewdata->get('medicine'))); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>